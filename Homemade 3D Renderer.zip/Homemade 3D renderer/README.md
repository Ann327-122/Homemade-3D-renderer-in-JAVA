### License
This project is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. You are free to share and adapt this work for non-commercial purposes, provided you give appropriate credit.

If you wish to use this engine for a commercial project, please contact me at: ann.dev.projects@gmail.com